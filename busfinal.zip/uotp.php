<?php
session_start();
include("connect.php");
include("menu.php");
if(isset($_POST['num']))
     {
	if($_SESSION["otp"]==$_POST["num"])
       {	
	$sql="update student set roll='$_SESSION[rollno]',name='$_SESSION[n]',adm='$_SESSION[admno]',mob='$_SESSION[mo]',email='$_SESSION[em]' where roll=$_SESSION[ad]";
	if ($conn->query($sql) === TRUE) 
	{	
	   if($_SESSION["b"]==$_SESSION["nb"])
		{echo "<br><h1 align=center>Done updating details!!</h1><br> ";}
		else
		{	
			echo "<br><h3 align=center><a href='busupdate.php'>click to change the bus</a></h4><br>";
		}
	}
	else
	 {
 	   echo "<h1 align=center><br>Error Updating " . $conn->error. "<br></h1>";
	  }
       }
	else
	{
		echo("wrong OTP");
	}
    }
	
?>