<html>
<body>
<table border=1 cellspacing=0 align='center'>
<tr>
<th width="5%">ROUTE</th>
<th width="40%">VIA</th>
<?php
	include("menu.php");
	include("connect.php");
	$sql="select * from buses";
	$res=mysqli_query($conn,$sql);
	while($bus=mysqli_fetch_array($res))
	{
		echo "<tr>";
		echo "<td>".$bus['route']."</td>";
		echo "<td>".$bus['via']."</td>";
		echo "</tr>";
	}
	
?>

</table>
</body>
</html>