<?php
session_start();
include("connect.php");
include("menu.php");
$but= "";
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
  $but =test_input($_POST["but"]);
}
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$l=$_SESSION["bu"];
$nl=$_SESSION["nbu"];
$n=$_SESSION["nb"];
$c=$_SESSION["ad"];
$m="select * from student where roll='".$_SESSION["ad"]."'";
$res=mysqli_query($conn,$m);
$o='0';
$j='1';
if(mysqli_affected_rows($conn)>0)
{
	while($row=mysqli_fetch_array($res))
	{
		$k=$row["seat"];
		$p="update $l set avail='$o' roll=' ' where seat='$k' ";
		$q=$conn->query($p);
		$new="update $nl set avail='$j' roll='$c' where seat='$but' ";
		$r=$conn->query($new);
		$sql="update student set bus='$n' , seat='$but' where roll='$c' ";
		$r=$conn->query($sql);
		echo "<br><h1 align=center>Updation completed!!</h1><br>";
	if(mysqli_affected_rows($conn)>0)
		{
			$sql="select * from student where roll='$c'";
			$res=$conn->query($sql);
			if($row=$res->fetch_assoc())
			{$msg="HI".$row["name"]." ! you(".$row["roll"].") have sucessfully updated your bus no to ".$row["bus"]."and your seat no is:".$row["seat"]."please show this as proof when required";
			mail($row["email"],'you have updated your bus sucessfully',$msg,'from: cbit.transport@gmail.com');}
			echo  "<h3> sucessfully updated " .$row['roll']. " bus no to ".$row['bus']."and your seat no ".$row['seat']. "</h3>";
		}
	}
}
?>