<?php
session_start();
include("connect.php");
include("menu.php");
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $name = test_input($_POST["name"]);
  $roll= test_input($_POST["roll"]);
  $adm = test_input($_POST["adm"]);
  $mob = test_input($_POST["mob"]);
  $busno = test_input($_POST["bus"]);
  $email = test_input($_POST["email"]);
}
$_SESSION["n"]=$name;
$_SESSION["rollno"]=$roll;
$_SESSION["mo"]=$mob;
$_SESSION["admno"]=$adm;
$_SESSION["em"]=$email;
$_SESSION["bus"]=$busno;
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$sql="SELECT* FROM student";
$result=$conn->query($sql);
$count=0;
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
	$r=$row["roll"];
	$n=$row["name"];
	$a=$row["adm"];
	$m=$row["mob"];
	$b=$row["bus"];
	$e=$row=["email"];
	 if($_SESSION["rollno"]==$r)
	   {
		$count=1;
		$to=$email;
		$sub="otp";	
		$otp=rand(100000,999999);
		$_SESSION["otp"]=$otp;
		$msg="OTP is: " .$otp."  it is valid for only 24 hours.";
		mail($to,$sub,$msg,'from: cbit.transport@gmail.com ');
		$_SESSION["ad"]=$_SESSION["rollno"];
		$_SESSION["nb"]=$_SESSION["bus"];
		$_SESSION["b"]=$b;
		echo "<form  align=center action='uotp.php' method=post name=fo ><br>Enter the OTP:<input type=text name=num ><br><input type=submit value=update ></form>";
	    }
		
	}
}

if($count==0)
{
	    echo "<br><h1 align=center>USER NOT REGISTERD!!</h1></br>";
}	
?>
</body>
</html>