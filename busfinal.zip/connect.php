<?php
$username = "root";
$password = '';
$db='rishi';
$conn = new mysqli("localhost", $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error. "<br>");
} 
//echo "Connected successfully<br>";
?>
