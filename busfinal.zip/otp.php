<?php
session_start();
include("connect.php");
include("menu.php");
if(isset($_POST['num']))
     {
	if($_SESSION["otp"]==$_POST["num"])
	{	
	$sql="insert into student(roll,name,adm,mob,email) values('$_SESSION[ro]','$_SESSION[n]','$_SESSION[ad]','$_SESSION[mo]','$_SESSION[em]')";
	
	if ($conn->query($sql) === TRUE) 
	{
		
	    echo "<br><h1 align=center>Registered successfully!! </h1><br>";
	    echo" <form  align=center method=post action='bus.php'>Bus No <input type=text  name=bus /><input type=submit value=availabiliy id=avail name=avail /></form>";
	} 
	else
	 {
 	   echo "<h1 align=center><br>Error Registering " . $conn->error. "<br></h1>";
	  }
	}
	else
	{
		echo("wrong OTP");
	}
    }
	
?>