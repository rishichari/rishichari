<html>
<body bgcolor="#FFC300" >
<a href="menu.php">Home</a><br>
<a href="form.php" style=" left:200px;">Bus Reservation</a><br>
<a href="updateform.php" style=" left:500px;">Update Reservation</a><br>
<a href="route.php">Bus Routes</a><br>
<a href="contact.html" style=" left:700px;">contact</a>
</body>
</html>