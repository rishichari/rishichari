<?php
session_start();
include("connect.php");
include("menu.php");
$but= "";
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
  $but =test_input($_POST["but"]);
}
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$l=$_SESSION["rou"];
$n=$_SESSION["no"];
$a=$_SESSION["r"];
$m="1";
$p="update $l set avail='$m',roll='$a' where seat='$but'";
$q=$conn->query($p);
$sql="update student set bus='$n',seat='$but' where roll='$a'";
$r=$conn->query($sql);
if(mysqli_affected_rows($conn)>0)
{
	$q="select* from student where roll='$a'";
	$res=$conn->query($q);
	if($row=$res->fetch_assoc())
	$msg="HI ".$row["name"]." ! you(".$row["roll"].") have sucessfully booked your seat in bus no: ".$row["bus"]."and your seat no is:".$row["seat"]." <br>please show this as proof when required";
	mail($row["email"],'you have booked your seat sucessfully',$msg,'from: cbit.transport@gmail.com');
		
}
echo "<br><h1 align=center>RollNo: " .$_SESSION["r"].  " have reserved your seat no. " .$but. "  in bus no. " .$n. "</h1><br>";
?>