<?php
session_start();
include("connect.php");
include("menu.php");
$bus= "";
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $bus = test_input($_POST["bus"]);
}
echo "<h3 align=center><br>BUS NO:" .$bus. "<br></h3>";
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if($bus=='10')
	{$x='ten'; }
if($bus=='12')
	{$x='twelve'; }
if($bus=='14')
	{$x='fourteen'; }
if($bus=='15')
	{$x='fifteen'; }
if($bus=='16')
	{$x='sixteen'; }
if($bus=='17')
	{$x='seventeen'; }
if($bus=='30')
	$x='thirty';
 $_SESSION["rou"]=$x;
$_SESSION["no"]=$bus;
$a="select* from $x order by seat";
$s=$conn->query($a);
if(mysqli_affected_rows($conn)>0)
{
	$n=$s->num_rows;
	$n=$n-3;
	$i=1;
	echo "<br><form align=center method=post action='sub.php'>";
	while($y=$s->fetch_assoc())
	{
		if($y["avail"]==0)
			{
				if(($i%6==3))
				{	
					if($i==$n)
					{return;}
					else{
					echo '<input type=button  style="width:5%;border:0;border-color:#FFC300; background-color:#FFC300;" onclick=y() >';
					$i++;}
				}
					echo '<input type=submit name=but  value='.$y["seat"].' style="background-color:green; width:5%;" >';
				if($i%6==0)
					echo "<br>";
			}
		else
			{
				if(($i%6==3))
				{	if($i==$n)
					{return;}
					else{
					echo '<input type=button  style="width:5%;border:0;border-color:#FFC300; background-color:#FFC300;" onclick=y() >';
					$i++;}
				}
					echo '<input type=button name=but  value='.$y["seat"]. ' style="background-color:red; width:5%;" onclick=a() >';
				if($i%6==0)
					echo "<br>";
		
			}
		$i++;
	}
	echo "</form>";
}
?>
<html>
<head>
<script type="text/javascript">
function a()
{
	alert('seat not available choose another seat');
}
function y()
{
	alert('select valid seat');
}

</script>
</head>
</html>