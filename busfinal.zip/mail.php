<?php
$m="hi";
$otp=rand(100000,999999);
if(mail('bandirishitha02@gmail.com','OTP',$otp,'from: cbit.transport@gmail.com'))
echo "bye";
else
 echo "error in sending";
?>