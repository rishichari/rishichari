<?php
include("menu.php");
include("connect.php");
?>
<html>
<script type="text/javascript">
function val()
{
	var r=document.forms["f"]["roll"].value;
	var l=document.forms["f"]["roll"].value.length;
	var n=document.forms["f"]["name"].value;
	var a=document.forms["f"]["adm"].value;
	var p=document.forms["f"]["adm"].value.length;
	var m=document.forms["f"]["mob"].value;
	var q=document.forms["f"]["mob"].value.length;
	var e=document.forms["f"]["email"].value;
	var d=em.lastIndexOf(".");
	
var a=em.indexOf("@");
	if(r=="" || r==null)
	{
		alert("roll number field cannot be empty");
		document.f.roll.focus();
		return false;
	}
	if(l<12 ||l>12 ||isNaN(r))
	{
		alert("enter valid roll no");
		document.f.roll.focus();
		return false;
	
	}
	if(n=="" ||n==null)
	{
		alert("name field cannot be empty");
		document.f.name.focus();
		return false;
	}
	if(a=="" ||a==null)
	{
		alert("Admission number field cannot be empty");
		document.f.adm.focus();
		return false;
	}
	if(p<=6 ||p>=9)
	{
		alert("enter valid admission no");
		document.f.adm.focus();
		return false;
	}
	if(m=="" ||m==null)
	{
		alert("mobile no field cannot be empty");
		document.f.adm.focus();
		return false;
	}
	if(q<10 ||q>10 || isNaN(m))
	{
		alert("enter valid mobile number");
		document.f.mob.focus();
		return false;
	}
	if(e=="" ||e==null)
	{
		alert("email field cannot be empty");
		document.f.email.focus();
		return false;
	}
	if(a<1 || d<1)
	
{
	
		alert("enter valid email");

		document.f.email.focus();

		return false;
	}
	
	return true;
	
	
}
</script>
<form align=center action="res.php" method="post" name=f onsubmit="return val();">
RollNo <input type=text name=roll id=roll /><br>
Name <input type=text name=name id=name /><br>
Admission No <input type=text name=adm id=adm /><br>
Mobile No <input type=text name=mob id=mob /><br>
Email <input type=text name=email id=email /><br>
click<input type=submit name=next  value=" next " /> to select bus route<br>
</form>
</html>