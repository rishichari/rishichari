<?php
session_start();
include("connect.php");
include("menu.php");
$name = $roll = $adm = $mob = $bus= "";
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  $name= test_input($_POST["name"]);
  $roll= test_input($_POST["roll"]);
  $ad = test_input($_POST["adm"]);
  $mob = test_input($_POST["mob"]);
  $email=test_input($_POST["email"]);
  $_SESSION["r"]=test_input($_POST["roll"]);
}
$_SESSION["n"]=$name;
$_SESSION["ro"]=$roll;
$_SESSION["mo"]=$mob;
$_SESSION["ad"]=$adm;
$_SESSION["em"]=$email;
function test_input($data)
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$sql="SELECT* FROM student";
$result=$conn->query($sql);
$count=0;
$_SESSION["adm"]=$roll;
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
	$r=$row["roll"];
	 if($roll==$r)
		{
		$count=1;
		echo "<br><h1 align=center>Already Registered!!</h1><br>";
		}
	}
}

if($count==0)
{

	
	$to=$email;
	$sub="otp";	
	$otp=rand(100000,999999);
	$_SESSION["otp"]=$otp;
	$msg="OTP is: " .$otp."  it is valid for only 24 hours.";
	mail($to,$sub,$msg,'from: cbit.transport@gmail.com ');
	echo "<form align=center  action='otp.php' method=post name=fo ><br>Enter the OTP:<input type=text name=num ><br><input type=submit value=update ></form>";
}
?>